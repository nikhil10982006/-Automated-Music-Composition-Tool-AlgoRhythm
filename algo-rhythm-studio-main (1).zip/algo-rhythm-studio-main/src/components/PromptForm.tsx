import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";

interface PromptFormProps {
  onResult?: (url: string) => void;
}

export default function PromptForm({ onResult }: PromptFormProps) {
  const [prompt, setPrompt] = useState("");
  const [backendUrl, setBackendUrl] = useState<string>(
    localStorage.getItem("algorhythm_backend_url") || ""
  );
  const [loading, setLoading] = useState(false);

  function saveEndpoint(url: string) {
    setBackendUrl(url);
    localStorage.setItem("algorhythm_backend_url", url);
  }

  const canSubmit = prompt.trim().length > 0 && !!backendUrl;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!backendUrl) {
      toast({ title: "Add your backend endpoint" });
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(backendUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      const ct = res.headers.get("content-type") || "";
      if (!res.ok) throw new Error(`Request failed: ${res.status}`);
      if (ct.includes("application/json")) {
        const data = await res.json();
        const url = data.audioUrl || data.audio_url || data.url || data.result?.audio;
        if (url) onResult?.(url);
      } else {
        const blob = await res.blob();
        onResult?.(URL.createObjectURL(blob));
      }
    } catch (e: any) {
      toast({ title: "Generation failed", description: e.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <Textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Describe your music idea..."
      />
      <div className="flex items-center gap-3">
        <Button type="submit" disabled={!canSubmit || loading} variant="hero">
          {loading ? "Generating…" : "Generate"}
        </Button>
        <Input
          value={backendUrl}
          onChange={(e) => saveEndpoint(e.target.value)}
          placeholder="Colab endpoint URL"
        />
      </div>
    </form>
  );
}
