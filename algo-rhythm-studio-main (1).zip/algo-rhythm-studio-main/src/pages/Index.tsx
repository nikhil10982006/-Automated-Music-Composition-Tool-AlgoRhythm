import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";
import { Music2, Sparkles, Wand2, Settings } from "lucide-react";

const LOGO_URL = "/lovable-uploads/5ac06e5e-9e30-433d-be9b-01302acfd02a.png";

function LightField() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onMove = (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      el.style.setProperty("--x", `${x}px`);
      el.style.setProperty("--y", `${y}px`);
    };
    el.addEventListener("mousemove", onMove);
    return () => el.removeEventListener("mousemove", onMove);
  }, []);
  return (
    <div
      ref={ref}
      aria-hidden
      className="pointer-events-none absolute inset-0 [mask-image:radial-gradient(200px_200px_at_var(--x)_var(--y),black,transparent)]"
      style={{
        background:
          "radial-gradient(600px 300px at var(--x) var(--y), hsl(var(--primary)/0.25), transparent 60%)",
      }}
    />
  );
}

const examples = [
  "Lo-fi chill beat with vinyl crackle, 90bpm",
  "Epic orchestral trailer theme, cinematic, 120bpm",
  "Futuristic synthwave with driving bass, 100bpm",
  "Ambient piano over gentle rain, 75bpm",
];

const storageKey = "algorhythm_backend_url";

const Index = () => {
  const [prompt, setPrompt] = useState("");
  const [backendUrl, setBackendUrl] = useState(
    localStorage.getItem(storageKey) || ""
  );
  const [loading, setLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem(storageKey, backendUrl);
  }, [backendUrl]);

  const canSubmit = useMemo(() => prompt.trim().length > 0 && !!backendUrl, [prompt, backendUrl]);

  async function handleGenerate() {
    if (!backendUrl) {
      toast({ title: "Add your backend endpoint", description: "Paste your Google Colab endpoint URL to connect." });
      return;
    }
    if (!prompt.trim()) {
      toast({ title: "Write a musical idea", description: "Describe the track you want to create." });
      return;
    }
    setLoading(true);
    setAudioUrl(null);
    try {
      const res = await fetch(backendUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      if (!res.ok) throw new Error(`Request failed: ${res.status}`);
      const ct = res.headers.get("content-type") || "";
      if (ct.includes("application/json")) {
        const data = await res.json();
        const url = data.audioUrl || data.audio_url || data.url || data.result?.audio;
        if (!url) throw new Error("No audio URL in response");
        setAudioUrl(url);
      } else if (ct.startsWith("audio")) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      } else {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      }
      toast({ title: "Track ready", description: "Hit play to listen or download." });
    } catch (e: any) {
      console.error(e);
      toast({ title: "Generation failed", description: e.message ?? "Please verify your endpoint." });
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-background relative overflow-hidden">
      <LightField />
      <header className="container mx-auto px-6 py-6 flex items-center justify-between">
        <a href="/" className="flex items-center gap-3">
          <img src={LOGO_URL} loading="lazy" alt="AlgoRhythm logo - AI Music Generator" className="h-10 w-10 object-contain" />
          <span className="font-display text-xl font-semibold">AlgoRhythm</span>
        </a>
        <nav className="hidden md:flex items-center gap-6 text-sm text-muted-foreground">
          <a className="story-link" href="#how-it-works">How it works</a>
          <a className="story-link" href="#examples">Examples</a>
          <a className="story-link" href="#get-started">Get started</a>
        </nav>
      </header>

      <section id="hero" className="container mx-auto px-6 pb-10 pt-4">
        <div className="mx-auto max-w-3xl text-center animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-bold font-display tracking-tight mb-4">
            AlgoRhythm — AI Music Generator
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8">
            Music Redefined. Turn your ideas into original tracks with the power of AI.
          </p>
          <Card className="bg-card/70 backdrop-blur border-border">
            <CardContent className="p-4 md:p-6">
              <div className="flex items-center gap-2 mb-3 text-sm text-muted-foreground">
                <Sparkles className="h-4 w-4" />
                <span>Describe your track and press Generate</span>
              </div>
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., Dreamy lo-fi beat with warm keys and soft rain ambience, 90bpm"
                className="mb-3"
                aria-label="Music prompt"
              />
              <div className="flex flex-col md:flex-row gap-3 md:items-center">
                <Button onClick={handleGenerate} disabled={!canSubmit || loading} variant="hero" className="md:w-auto">
                  {loading ? (
                    <span className="inline-flex items-center gap-2"><Music2 className="animate-spin" /> Generating…</span>
                  ) : (
                    <span className="inline-flex items-center gap-2"><Wand2 /> Generate</span>
                  )}
                </Button>
                <div className="flex-1" />
                <div className="flex items-center gap-2 w-full md:w-auto">
                  <Settings className="h-4 w-4 text-muted-foreground" />
                  <Input
                    value={backendUrl}
                    onChange={(e) => setBackendUrl(e.target.value)}
                    placeholder="Paste your Google Colab endpoint (POST)"
                    aria-label="Backend endpoint URL"
                  />
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2" id="examples">
                {examples.map((ex) => (
                  <button
                    key={ex}
                    type="button"
                    onClick={() => setPrompt(ex)}
                    className="px-3 py-1.5 rounded-md bg-secondary text-secondary-foreground hover-scale"
                  >
                    {ex}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
          {audioUrl && (
            <div className="mt-8 animate-scale-in" id="get-started">
              <audio controls src={audioUrl} className="w-full" />
              <div className="mt-2 text-sm text-muted-foreground">
                Tip: Right-click the player to download the track.
              </div>
            </div>
          )}
        </div>
      </section>

      <section id="how-it-works" className="container mx-auto px-6 pb-20">
        <div className="grid md:grid-cols-3 gap-6">
          {["Write your idea", "Connect your endpoint", "Generate & refine"].map((title, i) => (
            <Card key={i} className="animate-enter">
              <CardContent className="p-6">
                <div className="h-10 w-10 rounded-full bg-gradient-to-r from-brand to-primary text-primary-foreground grid place-items-center mb-4">
                  {i === 0 ? <Sparkles /> : i === 1 ? <Settings /> : <Music2 />}
                </div>
                <h3 className="font-semibold mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground">
                  {i === 0 && "Describe genre, mood, instruments, tempo — be as vivid as you like."}
                  {i === 1 && "Paste your Google Colab POST endpoint; AlgoRhythm will send { prompt } as JSON."}
                  {i === 2 && "Listen instantly. Tweak your prompt and generate variations in seconds."}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section aria-hidden className="absolute inset-x-0 -bottom-40 h-80 bg-gradient-to-t from-brand/10 to-transparent" />

      {/* Structured Data */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'SoftwareApplication',
        name: 'AlgoRhythm',
        applicationCategory: 'MultimediaApplication',
        description: 'AI music generator turning text prompts into original tracks.',
        operatingSystem: 'Web',
      }) }} />
    </main>
  );
};

export default Index;
